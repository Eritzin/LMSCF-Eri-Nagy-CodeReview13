<?php
namespace App\Controller;

// We need to import Response, Route, Request and Controller if we want to use them
use Symfony\ Component\HttpFoundation\Response;
use  Symfony\Component\Routing\Annotation\ Route;
use Symfony\Component\ HttpFoundation\Request;
use Symfony\ Bundle\FrameworkBundle\Controller\Controller ;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Entity\Events;

class EventsController extends Controller
{
   /**
    * @Route("/", name="home_page")
    */
   public function showAction()
   {     $events = $this->getDoctrine()->getRepository('App:Events')->findAll();
        return $this->render('events/index.html.twig',array('events'=>$events));
   }

    /**
    * @Route("/create", name="create_page")
    */
   public  function createAction(Request $request)
   {   
       $event = new Events;
/* Here we will build a form using createFormBuilder and inside this function we will put our object and then we write add then we select the input type then an array to add an attribute that we want in our input field */
       $form = $this->createFormBuilder($event)
       ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px ')))
       ->add('date', DateType::class, array('attr' => array('style'=>'margin-bottom:15px')))
       ->add('time', TimeType::class, array('attr' => array('style'=>'margin-bottom:15px; display:inline')))
       ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('capacity', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('contact_email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('contact_phone', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('address',  TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('event_url', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('type', ChoiceType::class, array('choices'=>array('Rock'=>'Rock', 'Classic'=>'Classic', 'POP'=>'POP','Movie'=>'Movie','Sport'=>'Sport','Theater'=>'Theater','Musical'=>'Musical' ),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
       ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-top:15px')))
       ->getForm();
       $form->handleRequest($request);
       

     
       if($form->isSubmitted() && $form->isValid()){
          
           $name = $form['name']->getData();
           $date = $form['date']->getData();
           $time = $form['time']->getData();
           $description = $form['description']->getData();
           $image = $form['image']->getData();
           $capacity = $form['capacity']->getData();
           $contact_email = $form['contact_email']->getData();
           $contact_phone = $form['contact_phone']->getData();
           $address = $form['address']->getData();
           $event_url = $form['event_url']->getData();
           $type = $form['type']->getData();
          
           $event->setName($name);
           $event->setDate($date);
           $event->setTime($time);
           $event->setDescription($description);
           $event->setImage($image);
           $event->setCapacity($capacity);
           $event->setContactEmail($contact_email);
           $event->setContactPhone($contact_phone);
           $event->setAddress($address);
           $event->setEventUrl($event_url);
           $event->setType($type);
           $em = $this->getDoctrine()->getManager();
           $em->persist($event);
           $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Added'
                   );
           return $this->redirectToRoute('home_page');
       }
       return  $this->render('events/create.html.twig' , array('form' => $form->createView()));
   }

    /**
    * @Route("/edit/{id}", name="edit_page")
    */
   public  function editAction($id, Request $request)
   {   
        $event = $this->getDoctrine()->getRepository('App:Events')->find($id);
           $event->setName($event->getName());
           $event->setDate($event->getDate());
           $event->setTime($event->getTime());
           $event->setDescription($event->getDescription());
           $event->setImage($event->getImage());
           $event->setCapacity($event->getCapacity());
           $event->setContactEmail($event->getContactEmail());
           $event->setContactPhone($event->getContactPhone());
           $event->setAddress($event->getAddress());
           $event->setEventUrl($event->getEventUrl());
           $event->setType($event->getType());
           

            $form = $this->createFormBuilder($event)
       ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('date', DateType::class, array('attr' => array('style'=>'margin-bottom:15px')))
       ->add('time', TimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
       ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('capacity', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('contact_email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('contact_phone', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('address',  TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('event_url', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('type', ChoiceType::class, array('choices'=>array('Rock'=>'Rock', 'Classic'=>'Classic', 'POP'=>'POP','Movie'=>'Movie','Sport'=>'Sport','Theater'=>'Theater','Musical'=>'Musical' ),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
       ->add('save', SubmitType::class, array('label'=> 'Update', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
       ->getForm();
       $form->handleRequest($request);
       if($form->isSubmitted() && $form->isValid()){
           //fetching data
           $name = $form['name']->getData();
           $date = $form['date']->getData();
           $time = $form['time']->getData();
           $description = $form['description']->getData();
           $image = $form['image']->getData();
           $capacity = $form['capacity']->getData();
           $contact_email = $form['contact_email']->getData();
           $contact_phone = $form['contact_phone']->getData();
           $address = $form['address']->getData();
           $event_url = $form['event_url']->getData();
           $type = $form['type']->getData();
           $em = $this->getDoctrine()->getManager();
           $event = $em->getRepository('App:Events')->find($id);
           $event->setName($name);
           $event->setDate($date);
           $event->setTime($time);
           $event->setDescription($description);
           $event->setImage($image);
           $event->setCapacity($capacity);
           $event->setContactEmail($contact_email);
           $event->setContactPhone($contact_phone);
           $event->setAddress($address);
           $event->setEventUrl($event_url);
           $event->setType($type);
          
          
           $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Edited'
                   );
           return $this->redirectToRoute('home_page');
       }
       return  $this->render('events/edit.html.twig', array('event' => $event, 'form' => $form->createView()));
   }

    /**
    * @Route("/details/{id}", name="details_page")
    */
   public  function detailsAction($id)
   {
         $event = $this->getDoctrine()->getRepository('App:Events')->find($id);
       return $this->render('events/details.html.twig', array('event' => $event));
   }


    /**
    * @Route("/delete/{id}", name="event_delete")
    */
   public function deleteAction($id){
            $em = $this->getDoctrine()->getManager();
           $event = $em->getRepository('App:Events')->find($id);
           $em->remove($event);
            $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Removed'
                   );
            return $this->redirectToRoute('home_page');
   }
}
?>